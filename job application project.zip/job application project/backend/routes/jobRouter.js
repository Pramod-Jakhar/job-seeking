import express from "express";
import { deletejob, getAllJobs, getSinglejob, getmyJobs, postJobs, updatejob } from "../controllers/jobController.js";
import { isAuthorized } from "../middlewares/auth.js";

const router=express.Router();
router.get("/getall",getAllJobs);
router.post("/post",isAuthorized,postJobs);
router.get("/getmyjobs",isAuthorized,getmyJobs);
router.put("/update/:id",isAuthorized,updatejob);
router.delete("/delete/:id",isAuthorized,deletejob);
router.get("/:id",isAuthorized,getSinglejob);




export default router; 