import mongoose from "mongoose";


const jobSchema = new mongoose.Schema({
    title:{
        type:String,
        required:[true, "Please provide job title!"],
        minlength:[3,"Job title must contain atleast 3 character!"],
        maxlength:[50,"Job title cannot exceeds 50 characters!"],
    },
    description:{
        type:String,
        required:[true, "Please provide job Description!"],
        minlength:[50,"Job description must contain atleast 50 character!"],
        maxlength:[350,"Job description cannot exceeds 350 characters!"],
    },
    category:{
        type:String,
        required:[true, "Job category is required!"],
    },
    country:{
        type:String,
        required:[true, "Job country is required!"],
    },
    city:{
        type:String,
        required:[true, "Job city is required!"],
    },
    location:{
        type:String,
        required:[true, "Please provide exact location!"],
        minlength:[20,"Job location must contain atleast 20 character!"],
    },
    fixedsalary:{
        type:Number,
        minlength:[4,"Fixed salary must contain atleast 4 digits!"],
        maxlength:[9,"Fixed salary cannot exceeds 9 digits!"],
    },
    salaryFrom:{
        type:Number,
        minlength:[4,"Salary must starts with atleast 4 digits!"],
        maxlength:[9,"Salary  cannot exceeds 9 digits!"],
    }, salaryTo:{
        type:Number,
        minlength:[4,"Salary must starts with atleast 4 digits!"],
        maxlength:[9,"Salary cannot exceeds 9 digits!"],
    },
    expired:{
        type:Boolean,
        default:false,
    },
    jobPostedOn:{
        type:Date,
        default:Date.now,
    },
    postedBy:{
        type:mongoose.Schema.ObjectId,
        ref:"User",
        required:true,
    },
    
    
    });
    
    export const Job=mongoose.model("Job",jobSchema);